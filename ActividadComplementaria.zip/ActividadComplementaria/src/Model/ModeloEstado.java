package Model;

import Include.Estado;
import Include.Localidades;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ModeloEstado extends Conexion {
    public boolean crearEstado (Estado estado){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta = "INSERT INTO estado"+"(ID_ESTADO, NOMBRE_ESTADO"+"VALUES(?,?)";
            pst=getConection().prepareStatement(consulta);
            pst.setInt(1,estado.getID_ESTADO());
            pst.setString(2,estado.getNOMBRE_ESTADO());

            if (pst.executeUpdate()==1){
                flag=true;
            }
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
        } finally {
            try {
                if (getConection() !=null) getConection().close();
                if (pst !=null) pst.close();
            }
            catch (Exception e){
            }
        }
        return flag;
    }
    public ArrayList<Estado> obtenerEstados(){
        ArrayList<Estado> estados=new ArrayList<Estado>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            String consulta = "SELECT ID_ESTADO, NOMBRE_ESTADO FROM estado";
            pst = getConection().prepareCall(consulta);
            rs = pst.executeQuery();
            while (rs.next()){
                estados.add(new Estado(rs.getInt("ID_ESTADO"),
                        rs.getString("NOMBRE_ESTADO")));
            }
        } catch (Exception e){
        }finally {

            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs !=null)rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return estados;
    }
    public ArrayList<Estado> obtenerEstado(int ID_ESTADO){
        ArrayList<Estado> estados =new ArrayList<Estado>();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            String consulta = "SELECT ID_ESTADO, NOMBRE_ESTADO FROM estado WHERE ID_ESTADO=?";
            pst = getConection().prepareCall(consulta);
            pst.setInt(1,ID_ESTADO);
            rs = pst.executeQuery();
            while (rs.next()){
                estados.add(new Estado(rs.getInt("ID_ESTADO"),
                        rs.getString("NOMBRE_ESTADO")));
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs != null) rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return estados;
    }
    public boolean actualizarEstado(Estado estado){
        PreparedStatement pst = null;
        boolean flag =false;
        try {
            String consulta = "UPDATE estado set ID_ESTADO = ?, NOMBRE_ESTADO =? WHERE ID_ESTADO = ?";
            pst=getConection().prepareStatement(consulta);
            pst.setInt(1,estado.getID_ESTADO());
            pst.setString(2,estado.getNOMBRE_ESTADO());

            if (pst.executeUpdate()==1){
                flag= true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {

            try {
                if (getConection()!=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception a){
                System.out.println(a.getMessage());
            }
        }
        return flag;
    }
    public boolean borrarEstado(int ID_ESTADO){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta ="DELETE FROM estado WHERE ID_ESTADO=?";
            pst = getConection().prepareStatement(consulta);
            pst.setInt(1,ID_ESTADO);

            if (pst.executeUpdate() ==1){
                flag=true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return flag;
    }
}
