package Model;

import Include.Localidades;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ModeloLocalidades extends Conexion {
    public boolean crearLocalidades(Localidades localidades){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta = "INSERT INTO localidades"+"(ID_LOCALIDADES, LOCALIDAD, municipio_ID_MUNICIPIO"+"VALUES(?,?,?)";
            pst=getConection().prepareStatement(consulta);
            pst.setInt(1,localidades.getID_LOCALIDADES());
            pst.setString(2,localidades.getLOCALIDAD());
            pst.setInt(3,localidades.getMunicipio_ID_MUNICIPIO());

            if (pst.executeUpdate()==1){
                flag=true;
            }
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
        } finally {
            try {
                if (getConection() !=null) getConection().close();
                if (pst !=null) pst.close();
            }
            catch (Exception e){
            }
        }
        return flag;
    }
    public ArrayList<Localidades> obtenerLocalidades(){
        ArrayList<Localidades> localidades=new ArrayList<Localidades>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            String consulta = "SELECT ID_LOCALIDADES, LOCALIDAD, municipio_ID_LOCALIDAD FROM localidades";
            pst = getConection().prepareCall(consulta);
            rs = pst.executeQuery();
            while (rs.next()){
                localidades.add(new Localidades(rs.getInt("ID_LOCALIDADES"),
                        rs.getString("LOCALIDAD"),
                        rs.getInt("municipio_ID_MUNICIPIO")));
            }
        } catch (Exception e){
        }finally {

            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs !=null)rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return localidades;
    }
    public ArrayList<Localidades> obtenerLocalidades(int ID_LOCALIDADES){
        ArrayList<Localidades> localidades =new ArrayList<Localidades>();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            String consulta = "SELECT ID_LOCALIDADES, LOCALIDAD, municipio_ID_MUNICIPIO WHERE ID_LOCALIDADES=?";
            pst = getConection().prepareCall(consulta);
            pst.setInt(1,ID_LOCALIDADES);
            rs = pst.executeQuery();
            while (rs.next()){
                localidades.add(new Localidades(rs.getInt("ID_LOCALIDADES"),
                        rs.getString("LOCALIDAD"),
                        rs.getInt("municipio_ID_MUNICIPIO")));
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs != null) rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return localidades;
    }
    public boolean actualizarLocalidades(Localidades localidades){
        PreparedStatement pst = null;
        boolean flag =false;
        try {
            String consulta = "UPDATE localidades set ID_LOCALIDADES = ?, LOCALIDAD =?, " +
                    "municipio_ID_MUNICIPIO =? " + "WHERE ID_LOCALIDADES = ?";
            pst=getConection().prepareStatement(consulta);
            pst.setInt(1,localidades.getID_LOCALIDADES());
            pst.setString(2,localidades.getLOCALIDAD());
            pst.setInt(3,localidades.getMunicipio_ID_MUNICIPIO());

            if (pst.executeUpdate()==1){
                flag= true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {

            try {
                if (getConection()!=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception a){
                System.out.println(a.getMessage());
            }
        }
        return flag;
    }
    public boolean borrarLocalidades(int ID_LOCALIDADES){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta ="DELETE FROM localidades WHERE ID_LOCALIDADES=?";
            pst = getConection().prepareStatement(consulta);
            pst.setInt(1,ID_LOCALIDADES);

            if (pst.executeUpdate() ==1){
                flag=true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return flag;
    }
}
