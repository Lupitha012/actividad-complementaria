package Model;


import Include.Municipio;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ModeloMunicipio extends Conexion {
    public boolean crearMunicipios (Municipio municipio){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta= "INSERT INTO Municipio" + "(ID_MUNICIPIO, NOMBRE_MUNICIPIO, estado_ID_ESTADO)" + "VALUES(?,?,?)";
            pst = getConection().prepareStatement(consulta);
            pst.setInt(1,municipio.getID_MUNICIPIO());
            pst.setString(2,municipio.getNOMBRE_MUNICIPIO());
            pst.setInt(3,municipio.getEstado_ID_ESTADO());

            if (pst.executeUpdate()==1){
                flag=true;
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                if (getConection() !=null) getConection().close();
                if (pst !=null) pst.close();
            }
            catch (Exception e){
            }
        }
        return flag;
    }

    public ArrayList<Municipio> obtenerMunicipio(){
        ArrayList<Municipio> municipios=new ArrayList<Municipio>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            String consulta = "SELECT ID_MUNICIPIO, NOMBRE_MUNICIPIO, estado_ID_MUNICIPIO FROM municipio";
            pst = getConection().prepareCall(consulta);
            rs = pst.executeQuery();
            while (rs.next()){
                municipios.add(new Municipio(rs.getInt("ID_MUNICIPIO"),
                        rs.getString("NOMBRE_MUNICIPIO"),
                        rs.getInt("estado_ID_MUNICIPIO")));
            }
        } catch (Exception e){
        }finally {

            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs !=null)rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return municipios;
    }

    public ArrayList<Municipio> obtenerMunicipio(int ID_MUNICIPIO){
        ArrayList<Municipio> municipios =new ArrayList<Municipio>();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            String consulta = "SELECT ID_MUNICIPIO, NOMBRE_MUNICIPIO, estado_ID_MUNICIPIO FROM municipio WHERE ID_MUNICIPIO=?";
            pst = getConection().prepareCall(consulta);
            pst.setInt(1,ID_MUNICIPIO);
            rs = pst.executeQuery();
            while (rs.next()){
                municipios.add(new Municipio(rs.getInt("ID_MUNICIPIO"),
                        rs.getString("NOMBRE_MUNICIPIO"),
                        rs.getInt("estado_ID_MUNICIPIO")));
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null)pst.close();
                if (rs != null) rs.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return municipios;
    }

    public boolean actualizarMunicipio(Municipio municipio){
        PreparedStatement pst = null;
        boolean flag =false;
        try {
            String consulta = "UPDATE municipio set ID_MUNICIPIO = ?, NOMBRE_MUNICIPIO =?, estado_ID_MUNICIPIO =? WHERE ID_MUNICIPIO=?";
            pst=getConection().prepareStatement(consulta);
            pst.setInt(1,municipio.getID_MUNICIPIO());
            pst.setString(2,municipio.getNOMBRE_MUNICIPIO());
            pst.setInt(3,municipio.getEstado_ID_ESTADO());
            pst.setInt(4,municipio.getID_MUNICIPIO());

            if (pst.executeUpdate()==1){
                flag= true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {

            try {
                if (getConection()!=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception a){
                System.out.println(a.getMessage());
            }
        }
        return flag;
    }
    public boolean borrarMunicipio(int ID_MUNICIPIO){
        PreparedStatement pst = null;
        boolean flag = false;
        try {
            String consulta ="DELETE FROM municipio WHERE ID_MUNICIPIO=?";
            pst = getConection().prepareStatement(consulta);
            pst.setInt(1,ID_MUNICIPIO);

            if (pst.executeUpdate() ==1){
                flag=true;
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally {
            try {
                if (getConection() !=null)getConection().close();
                if (pst !=null) pst.close();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        return flag;
    }
}


