package Include;

public class Municipio {
    private int ID_MUNICIPIO;
    private String NOMBRE_MUNICIPIO;
    private int estado_ID_ESTADO;


    public Municipio(int ID_MUNICIPIO, String NOMBRE_MUNICIPIO, int estado_ID_ESTADO) {
        this.ID_MUNICIPIO = ID_MUNICIPIO;
        this.NOMBRE_MUNICIPIO = NOMBRE_MUNICIPIO;
        this.estado_ID_ESTADO = estado_ID_ESTADO;
    }

    public int getID_MUNICIPIO() {
        return ID_MUNICIPIO;
    }

    public void setID_MUNICIPIO(int ID_MUNICIPIO) {
        this.ID_MUNICIPIO = ID_MUNICIPIO;
    }

    public String getNOMBRE_MUNICIPIO() {
        return NOMBRE_MUNICIPIO;
    }

    public void setNOMBRE_MUNICIPIO(String NOMBRE_MUNICIPIO) {
        this.NOMBRE_MUNICIPIO = NOMBRE_MUNICIPIO;
    }

    public int getEstado_ID_ESTADO() {
        return estado_ID_ESTADO;
    }

    public void setEstado_ID_ESTADO(int estado_ID_ESTADO) {
        this.estado_ID_ESTADO = estado_ID_ESTADO;
    }
}
