package Include;

public class Estado {
    private int ID_ESTADO;
    private String NOMBRE_ESTADO;

    public Estado(int ID_ESTADO, String NOMBRE_ESTADO) {
        this.ID_ESTADO = ID_ESTADO;
        this.NOMBRE_ESTADO = NOMBRE_ESTADO;
    }

    public int getID_ESTADO() {
        return ID_ESTADO;
    }

    public void setID_ESTADO(int ID_ESTADO) {
        this.ID_ESTADO = ID_ESTADO;
    }

    public String getNOMBRE_ESTADO() {
        return NOMBRE_ESTADO;
    }

    public void setNOMBRE_ESTADO(String NOMBRE_ESTADO) {
        this.NOMBRE_ESTADO = NOMBRE_ESTADO;
    }
}
