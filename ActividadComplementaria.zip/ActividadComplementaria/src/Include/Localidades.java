package Include;

public class Localidades {
    private int ID_LOCALIDADES;
    private String LOCALIDAD;
    private int municipio_ID_MUNICIPIO;

    public Localidades(int ID_LOCALIDADES, String LOCALIDAD, int municipio_ID_MUNICIPIO) {
        this.ID_LOCALIDADES = ID_LOCALIDADES;
        this.LOCALIDAD = LOCALIDAD;
        this.municipio_ID_MUNICIPIO = municipio_ID_MUNICIPIO;
    }

    public int getID_LOCALIDADES() {
        return ID_LOCALIDADES;
    }

    public void setID_LOCALIDADES(int ID_LOCALIDADES) {
        this.ID_LOCALIDADES = ID_LOCALIDADES;
    }

    public String getLOCALIDAD() {
        return LOCALIDAD;
    }

    public void setLOCALIDAD(String LOCALIDAD) {
        this.LOCALIDAD = LOCALIDAD;
    }

    public int getMunicipio_ID_MUNICIPIO() {
        return municipio_ID_MUNICIPIO;
    }

    public void setMunicipio_ID_MUNICIPIO(int municipio_ID_MUNICIPIO) {
        this.municipio_ID_MUNICIPIO = municipio_ID_MUNICIPIO;
    }
}
