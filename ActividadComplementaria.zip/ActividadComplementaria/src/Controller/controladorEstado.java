package Controller;

import Include.Estado;
import Model.ModeloEstado;

import java.util.ArrayList;

public class controladorEstado {
    public boolean agregarEstado(Estado estado){
        ModeloEstado estado1 = new ModeloEstado();
        return estado1.crearEstado (estado);
    }

    public ArrayList<Estado> obtenerEstado(){
        ModeloEstado estado = new ModeloEstado();
        return estado.obtenerEstado(estado);
    }

    public ArrayList<Estado> obtenerEstado(int ID_ESTADO){
        ModeloEstado estado1 = new ModeloEstado();
        return estado1.obtenerEstado(ID_ESTADO);
    }

    public boolean actualizarEstado(Estado estado){
        ModeloEstado estado1 = new ModeloEstado();
        return estado1.actualizarEstado(estado);
    }

    public boolean eliminarEstado(int ID_ESTADO){
        ModeloEstado estado = new ModeloEstado();
        return estado.borrarEstado(ID_ESTADO);
    }
    public static void main(String[]args){
        controladorEstado ce = new controladorEstado();
        System.out.println(ce.agregarEstado(new Estado(1,"Guerrero")));

        //Listar todos los elementos de la tabla
        ArrayList<Estado> estados = new ArrayList<Estado>();
        estados= ce.obtenerEstado();
        for (int a=0; a<estados.size(); a++){
            System.out.println("ID_ESTADO: " + estados.get(a).getID_ESTADO());
            System.out.println("NOMBRE_ESTADO " + estados.get(a).getNOMBRE_ESTADO());
            System.out.println();
        }

        //Listar un elemento de la tabla por su llave primaria
        ArrayList<Estado> estados1 = new ArrayList<Estado>();
        estados = ce.obtenerEstado(1);

        for (int b=0; b<estados.size();b++){
            System.out.println("ID_ESTADO: " + estados.get(b).getID_ESTADO());
            System.out.println("NOMBRE_ESTADO: " + estados.get(b).getNOMBRE_ESTADO());
            System.out.println();
        }
        //Modificar un elemento
        System.out.println(ce.actualizarEstado(new Estado(2,"Mexico")));

        //modificar un elemento

        System.out.println(ce.eliminarEstado(2));
    }
}
