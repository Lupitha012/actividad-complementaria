package Controller;

import Include.Municipio;
import Model.ModeloMunicipio;

import java.util.ArrayList;

public class controladorMunicipio {
    public boolean agregarMunicipio(Municipio municipio){
        ModeloMunicipio municipio1 = new ModeloMunicipio();
        return  municipio1.crearMunicipios(municipio);
    }
    public ArrayList<Municipio> obtenerMunicipio(){
        ModeloMunicipio municipio = new ModeloMunicipio();
        return municipio.obtenerMunicipio();
    }
    public ArrayList<Municipio>obtenerMunicipio(int ID_MUNICIPIO){
        ModeloMunicipio municipio1 = new ModeloMunicipio();
        return municipio1.obtenerMunicipio(ID_MUNICIPIO);
    }
    public boolean actualizarMunicipio(Municipio municipio){
        ModeloMunicipio municipio1 = new ModeloMunicipio();
        return municipio1.actualizarMunicipio(municipio);
    }
    public boolean eliminarMunicipio(int ID_MUNICIPIO){
        ModeloMunicipio municipio1 = new ModeloMunicipio();
        return municipio1.borrarMunicipio(ID_MUNICIPIO);
    }
    public static void main (String[]args){
        controladorMunicipio cm= new controladorMunicipio();
        System.out.println(cm.agregarMunicipio(new Municipio(2,"Coyuca",07)));


        //Listar todos los elementos de una tabla
      /*  ArrayList<Municipio> municipios = new ArrayList<Municipio>();
        municipios= cm.obtenerMunicipio();
        for (int a=0; a<municipios.size(); a++){
            System.out.println("ID_MUNICIPIO: " + municipios.get(a).getID_MUNICIPIO());
            System.out.println("NOMBRE_MUNICIPIO: " + municipios.get(a).getNOMBRE_MUNICIPIO());
            System.out.println("estado_ID_MUNICIPIO: " + municipios.get(a).getEstado_ID_ESTADO());
            System.out.println();
        }
        //Listar un elemento de la tabla por su llave primaria
        ArrayList<Municipio> municipios1 = new ArrayList<Municipio>();
        municipios1 = cm.obtenerMunicipio();

        for (int b=0; b<municipios.size();b++){
            System.out.println("ID_MUNICIPIO: " + municipios.get(b).getID_MUNICIPIO());
            System.out.println("NOMBRE_MUNICIPIO: " + municipios.get(b).getNOMBRE_MUNICIPIO());
            System.out.println("estado_ID_ESTADO: " + municipios.get(b).getEstado_ID_ESTADO());
            System.out.println();
        }
        //Modificar un elemento
        System.out.println(cm.actualizarMunicipio(new Municipio(1,"Pungarabato",6)));

        //modificar un elemento

        System.out.println(cm.eliminarMunicipio(2));*/
    }
}



