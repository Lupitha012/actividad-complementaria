package Controller;

import Include.Localidades;
import Model.ModeloLocalidades;

import java.util.ArrayList;

public class controladorLocalidades {

    public ArrayList<Localidades> obtenerLocalidades() {
        ModeloLocalidades localidades = new ModeloLocalidades();
        return localidades.obtenerLocalidades();
    }

    public ArrayList<Localidades> obtenerLocalidades(int ID_LOCALIDADES) {
        ModeloLocalidades localidades = new ModeloLocalidades();
        return localidades.obtenerLocalidades(ID_LOCALIDADES);
    }
    public static void main (String[]args){
        controladorLocalidades cl= new controladorLocalidades();

        ArrayList<Localidades> localidades = new ArrayList<Localidades>();
        localidades= cl.obtenerLocalidades();
        for (int a=0; a<localidades.size(); a++){
            System.out.println("ID_LOCALIDADES: " + localidades.get(a).getID_LOCALIDADES());
            System.out.println("LOCALIDAD: " + localidades.get(a).getLOCALIDAD());
            System.out.println("municipioID_MUNICIPIO: " +localidades.get(a).getMunicipio_ID_MUNICIPIO());
            System.out.println();
        }
    }
}
